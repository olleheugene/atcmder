from PySide6.QtWidgets import QAbstractScrollArea, QSizePolicy
from PySide6.QtGui import QPainter, QColor, QFont, QFontMetrics, QPalette
from PySide6.QtCore import Qt
import re

class TerminalWidget(QAbstractScrollArea):
    def __init__(self, parent=None, font_family="Monaco", font_size=14):
        super().__init__(parent)
        self.font = QFont(font_family, font_size)
        self.font.setStyleHint(QFont.StyleHint.Monospace)
        self.font_metrics = QFontMetrics(self.font)
        self.line_height = self.font_metrics.height()
        self.char_width = self.font_metrics.horizontalAdvance('M')
        
        # 터미널 데이터 저장
        self.lines = []
        self.max_lines = 1000
        self.scroll_offset = 0
        
        # ANSI 색상 매핑
        self.ansi_colors = {
            30: QColor(0, 0, 0),        # Black
            31: QColor(205, 49, 49),    # Red
            32: QColor(13, 188, 121),   # Green
            33: QColor(229, 229, 16),   # Yellow
            34: QColor(36, 114, 200),   # Blue
            35: QColor(188, 63, 188),   # Magenta
            36: QColor(17, 168, 205),   # Cyan
            37: QColor(229, 229, 229),  # White
            90: QColor(102, 102, 102),  # Bright Black
            91: QColor(241, 76, 76),    # Bright Red
            92: QColor(35, 209, 139),   # Bright Green
            93: QColor(245, 245, 67),   # Bright Yellow
            94: QColor(59, 142, 234),   # Bright Blue
            95: QColor(214, 112, 214),  # Bright Magenta
            96: QColor(41, 184, 219),   # Bright Cyan
            97: QColor(255, 255, 255),  # Bright White
        }
        self.default_color = QColor(200, 200, 200)
        self.current_color = self.default_color
        
        # 스크롤바 정책 설정 - 강제로 표시
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        
        # 배경색 설정
        self.setAutoFillBackground(True)
        palette = self.palette()
        palette.setColor(QPalette.ColorRole.Base, QColor(30, 30, 30))
        self.setPalette(palette)
        
        # 스크롤바 연결
        self.verticalScrollBar().valueChanged.connect(self.on_vertical_scroll)
        self.horizontalScrollBar().valueChanged.connect(self.on_horizontal_scroll)

        # 창 크기에 맞춰 자동으로 크기 조절
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def on_vertical_scroll(self, value):
        """세로 스크롤바 변경 시"""
        visible_lines = max(1, self.viewport().height() // self.line_height)
        total_lines = len(self.lines)
        
        if total_lines > visible_lines:
            max_scroll = total_lines - visible_lines
            self.scroll_offset = max_scroll - value
            self.viewport().update()

    def on_horizontal_scroll(self, value):
        """가로 스크롤바 변경 시"""
        self.viewport().update()

    def resizeEvent(self, event):
        """크기 변경 시 스크롤바 업데이트"""
        super().resizeEvent(event)
        self.update_scrollbar()

    def set_font(self, font):
        """폰트 설정"""
        self.font = font
        self.font_metrics = QFontMetrics(self.font)
        self.line_height = self.font_metrics.height()
        self.char_width = self.font_metrics.horizontalAdvance('M')
        self.update_scrollbar()
        self.viewport().update()

    def parse_ansi_text(self, text):
        """ANSI 시퀀스를 파싱하여 텍스트와 색상 정보 반환"""
        result = []
        ansi_escape = re.compile(r'\x1B\[[0-?]*[ -/]*[@-~]')
        current_color = self.current_color
        pos = 0
        
        for match in ansi_escape.finditer(text):
            # 일반 텍스트 부분
            if pos < match.start():
                text_part = text[pos:match.start()]
                if text_part:
                    result.append((text_part, current_color))
            
            # ANSI 코드 파싱
            ansi_code = match.group()
            if ansi_code.endswith('m'):
                try:
                    code_str = ansi_code[2:-1]  # \x1B[...m에서 숫자 부분만
                    if code_str == '0' or code_str == '':  # Reset
                        current_color = self.default_color
                    elif ';' in code_str:  # 여러 코드
                        codes = code_str.split(';')
                        for code in codes:
                            if code.isdigit():
                                color_code = int(code)
                                if color_code in self.ansi_colors:
                                    current_color = self.ansi_colors[color_code]
                                elif color_code == 0:
                                    current_color = self.default_color
                    elif code_str.isdigit():
                        color_code = int(code_str)
                        if color_code in self.ansi_colors:
                            current_color = self.ansi_colors[color_code]
                        elif color_code == 0:
                            current_color = self.default_color
                except ValueError:
                    pass
            
            pos = match.end()
        
        # 남은 텍스트
        if pos < len(text):
            remaining_text = text[pos:]
            if remaining_text:
                result.append((remaining_text, current_color))
        
        # 현재 색상 업데이트
        self.current_color = current_color
        
        return result

    def append_text(self, text):
        """텍스트 추가 - 개선된 줄바꿈 및 백스페이스 처리"""
        if not text:
            return

        text = text.replace('\r\n', '\n').replace('\r', '\n')
        lines = text.split('\n')

        for i, line in enumerate(lines):
            if i > 0:
                self.lines.append([])
            idx = 0
            while idx < len(line):
                if line[idx] == '\b':
                    self.remove_last_char()
                    idx += 1
                else:
                    # ANSI 시퀀스 처리
                    ansi_match = re.match(r'\x1B\[[0-?]*[ -/]*[@-~]', line[idx:])
                    if ansi_match:
                        ansi_seq = ansi_match.group()
                        parsed = self.parse_ansi_text(ansi_seq)
                        if not self.lines:
                            self.lines.append([])
                        self.lines[-1].extend(parsed)
                        idx += len(ansi_seq)
                    else:
                        # 일반 문자
                        if not self.lines:
                            self.lines.append([])
                        self.lines[-1].append((line[idx], self.current_color))
                        idx += 1
            if i == 0 and not self.lines:
                self.lines.append([])

        if text.endswith('\n') and self.lines and self.lines[-1]:
            self.lines.append([])

        while len(self.lines) > self.max_lines:
            self.lines.pop(0)

        self.scroll_offset = 0
        self.update_scrollbar()
        self.viewport().update()

    def append_ansi_text(self, text):
        """ANSI 텍스트 추가"""
        self.append_text(text)

    def clear(self):
        """화면 클리어"""
        self.lines = []
        self.scroll_offset = 0
        self.current_color = self.default_color
        self.update_scrollbar()
        self.viewport().update()

    def update_scrollbar(self):
        """스크롤바 업데이트 - 개선된 버전"""
        if self.line_height <= 0:
            self.line_height = 20
        
        viewport_height = self.viewport().height()
        viewport_width = self.viewport().width()
        
        if viewport_height <= 0 or viewport_width <= 0:
            return
        
        visible_lines = max(1, viewport_height // self.line_height)
        total_lines = len(self.lines)
        
        # 세로 스크롤바
        self.verticalScrollBar().blockSignals(True)
        if total_lines > visible_lines:
            max_scroll = total_lines - visible_lines
            self.verticalScrollBar().setRange(0, max_scroll)
            self.verticalScrollBar().setPageStep(visible_lines)
            self.verticalScrollBar().setSingleStep(1)
            
            # 스크롤 위치 설정 (최신 내용이 보이도록)
            scroll_value = max_scroll - self.scroll_offset
            self.verticalScrollBar().setValue(scroll_value)
        else:
            self.verticalScrollBar().setRange(0, 0)
            self.verticalScrollBar().setValue(0)
        self.verticalScrollBar().blockSignals(False)
        
        # 가로 스크롤바
        max_line_width = 0
        for line_parts in self.lines:
            line_width = 0
            for text_part, color in line_parts:
                if text_part:
                    line_width += self.font_metrics.horizontalAdvance(text_part)
            max_line_width = max(max_line_width, line_width)
        
        content_width = max_line_width + 20  # 여백
        
        self.horizontalScrollBar().blockSignals(True)
        if content_width > viewport_width:
            max_h_scroll = content_width - viewport_width
            self.horizontalScrollBar().setRange(0, max_h_scroll)
            self.horizontalScrollBar().setPageStep(viewport_width)
            self.horizontalScrollBar().setSingleStep(20)
        else:
            self.horizontalScrollBar().setRange(0, 0)
            self.horizontalScrollBar().setValue(0)
        self.horizontalScrollBar().blockSignals(False)

    def paintEvent(self, event):
        """페인트 이벤트 - 가로/세로 스크롤 지원"""
        painter = QPainter(self.viewport())
        painter.setFont(self.font)
        
        # 배경 그리기
        painter.fillRect(self.viewport().rect(), QColor(30, 30, 30))
        
        if not self.lines:
            painter.end()
            return
        
        # 보이는 영역 계산
        viewport_rect = self.viewport().rect()
        visible_lines = max(1, viewport_rect.height() // self.line_height)
        
        # 가로 스크롤 오프셋
        h_scroll_offset = self.horizontalScrollBar().value()
        
        # 세로 스크롤 오프셋에 따른 시작/끝 라인 계산
        total_lines = len(self.lines)
        start_line = max(0, total_lines - visible_lines - self.scroll_offset)
        end_line = min(total_lines, start_line + visible_lines)
        
        # 텍스트 그리기
        y = 5
        for line_idx in range(start_line, end_line):
            if line_idx < len(self.lines):
                line_parts = self.lines[line_idx]
                x = 5 - h_scroll_offset  # 가로 스크롤 적용
                
                # 각 텍스트 부분을 색상과 함께 그리기
                for text_part, color in line_parts:
                    if text_part:
                        text_width = self.font_metrics.horizontalAdvance(text_part)
                        
                        # 화면에 보이는 부분만 그리기 (성능 최적화)
                        if x + text_width > 0 and x < viewport_rect.width():
                            painter.setPen(color)
                            painter.drawText(x, y + self.font_metrics.ascent(), text_part)
                        
                        x += text_width
        
            y += self.line_height
        
        painter.end()

    def wheelEvent(self, event):
        """휠 이벤트"""
        delta = event.angleDelta().y()
        scroll_lines = 3
        
        visible_lines = max(1, self.viewport().height() // self.line_height)
        total_lines = len(self.lines)
        max_scroll = max(0, total_lines - visible_lines)
        
        if delta > 0:  # 위로 스크롤
            self.scroll_offset = min(self.scroll_offset + scroll_lines, max_scroll)
        else:  # 아래로 스크롤
            self.scroll_offset = max(0, self.scroll_offset - scroll_lines)
        
        self.update_scrollbar()
        self.viewport().update()
        event.accept()

    def scrollContentsBy(self, dx, dy):
        """스크롤바 드래그 처리 - 가로/세로 모두 지원"""
        if dy != 0:  # 세로 스크롤
            visible_lines = max(1, self.viewport().height() // self.line_height)
            total_lines = len(self.lines)
            
            if total_lines > visible_lines:
                scroll_value = self.verticalScrollBar().value()
                max_scroll = total_lines - visible_lines
                
                # 스크롤 오프셋 계산
                self.scroll_offset = max_scroll - scroll_value
    
        # 가로 스크롤은 자동으로 처리됨 (horizontalScrollBar().value() 사용)
        
        self.viewport().update()

    def keyPressEvent(self, event):
        """키 이벤트 - 스크롤 관련만 처리"""
        visible_lines = max(1, self.viewport().height() // self.line_height)
        total_lines = len(self.lines)
        max_scroll = max(0, total_lines - visible_lines)
        
        if event.key() == Qt.Key.Key_PageUp:
            self.scroll_offset = min(self.scroll_offset + visible_lines, max_scroll)
            self.update_scrollbar()
            self.viewport().update()
        elif event.key() == Qt.Key.Key_PageDown:
            self.scroll_offset = max(0, self.scroll_offset - visible_lines)
            self.update_scrollbar()
            self.viewport().update()
        elif event.key() == Qt.Key.Key_Home and event.modifiers() == Qt.KeyboardModifier.ControlModifier:
            self.scroll_offset = max_scroll
            self.update_scrollbar()
            self.viewport().update()
        elif event.key() == Qt.Key.Key_End and event.modifiers() == Qt.KeyboardModifier.ControlModifier:
            self.scroll_offset = 0
            self.update_scrollbar()
            self.viewport().update()
        else:
            super().keyPressEvent(event)

    def handle_backspace(self):
        """백스페이스 처리 - 개선된 버전"""
        if self.current_input_buffer:
            # 버퍼에서 마지막 문자 제거
            deleted_char = self.current_input_buffer[-1]
            self.current_input_buffer = self.current_input_buffer[:-1]
            self.history_index = -1  # 편집 시 히스토리 인덱스 리셋
            
            # 화면에서 문자 지우기 - 더 명확한 백스페이스 시퀀스
            self.terminal_widget.append_text('\b')  # 백스페이스만 전송
            
            self.show_current_input()

    def remove_last_char(self):
        """현재 줄에서 마지막 문자(글자) 하나를 지움"""
        if not self.lines:
            return
        # 마지막 줄이 비어있지 않으면
        if self.lines[-1]:
            last_text, last_color = self.lines[-1][-1]
            if len(last_text) > 1:
                # 여러 글자면 마지막 글자만 제거
                self.lines[-1][-1] = (last_text[:-1], last_color)
            else:
                # 한 글자면 해당 부분 삭제
                self.lines[-1].pop()
                # 줄이 완전히 비었고 첫 줄이 아니면 줄도 삭제
                if not self.lines[-1] and len(self.lines) > 1:
                    self.lines.pop()
        else:
            # 현재 줄이 비어있으면 이전 줄로 이동해서 삭제
            if len(self.lines) > 1:
                self.lines.pop()
                self.remove_last_char()